class Unbuffered(object):
   def __init__(self, stream):
       self.stream = stream
   def write(self, data):
       self.stream.write(data)
       self.stream.flush()
   def __getattr__(self, attr):
       return getattr(self.stream, attr)
import sys
sys.stdout = Unbuffered(sys.stdout)
import os
from Crypto.Cipher import AES
from Crypto.Util.number import *
import random

def egcd(a, b):
    if a == 0:
        return (b, 0, 1)
    else:
        g, y, x = egcd(b % a, a)
        return (g, x - (b // a) * y, y)

def invert(a, m):
    g, x, y = egcd(a, m)
    if g != 1:
        raise Exception('modular inverse does not exist')
    else:
        return x % m

os.chdir("/home/ctf")
flag=open("flag","rb").read()
p=getPrime(512)
q=getPrime(512)
n=p*q
e=0x10001
d=invert(e,(p-1)*(q-1))
secret=os.urandom(32)
pp=getPrime(512)
qq=getPrime(512)
nn=pp*qq
dd=invert(e,(pp-1)*(qq-1))



def u():
    secret=os.urandom(32)

def l():
    m=bytes_to_long(secret)
    c=pow(m,e,n)
    print c

def p():
    rc=int(raw_input())
    if rc!=pow(bytes_to_long(secret),e,n):
        print pow(rc,d,n)

def o():
    rs=int(raw_input())
    if rs==bytes_to_long(secret):
        rc=int(raw_input())
        print pow(rc,dd,nn)%2


def run():
    print "llp"
    print n
    print nn
    print pow(bytes_to_long(flag),e,nn)
    while 1:
        choice=raw_input(">")
        if choice=="u":
            u()
        elif choice=="l":
            l()
        elif choice=="p":
            p()
        elif choice=="o":
            o()
        else:
            print "wrong"



if __name__ == '__main__':
    run()
