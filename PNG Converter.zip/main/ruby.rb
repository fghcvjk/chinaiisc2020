#!/usr/bin/ruby -w
#-*- coding:utf-8 -*-

#  /$$$$$$$  /$$   /$$  /$$$$$$         /$$$$$$                                                      /$$                        
# | $$__  $$| $$$ | $$ /$$__  $$       /$$__  $$                                                    | $$                        
# | $$  \ $$| $$$$| $$| $$  \__/      | $$  \__/  /$$$$$$  /$$$$$$$  /$$    /$$ /$$$$$$   /$$$$$$  /$$$$$$    /$$$$$$   /$$$$$$ 
# | $$$$$$$/| $$ $$ $$| $$ /$$$$      | $$       /$$__  $$| $$__  $$|  $$  /$$//$$__  $$ /$$__  $$|_  $$_/   /$$__  $$ /$$__  $$
# | $$____/ | $$  $$$$| $$|_  $$      | $$      | $$  \ $$| $$  \ $$ \  $$/$$/| $$$$$$$$| $$  \__/  | $$    | $$$$$$$$| $$  \__/
# | $$      | $$\  $$$| $$  \ $$      | $$    $$| $$  | $$| $$  | $$  \  $$$/ | $$_____/| $$        | $$ /$$| $$_____/| $$      
# | $$      | $$ \  $$|  $$$$$$/      |  $$$$$$/|  $$$$$$/| $$  | $$   \  $/  |  $$$$$$$| $$        |  $$$$/|  $$$$$$$| $$      
# |__/      |__/  \__/ \______/        \______/  \______/ |__/  |__/    \_/    \_______/|__/         \___/   \_______/|__/      
                                                                                                                              
require 'nokogiri'  
require 'open-uri'  
require 'base64'  
require 'uri'
require 'pathname'
require 'fileutils'
require 'shellwords'  

String.class_eval do
    def is_valid_url?
        uri = URI.parse self
        if uri.kind_of? URI::HTTPS
            return false
        end
        uri.kind_of? URI::HTTP
    rescue URI::InvalidURIError
        false
    end

    def is_valid_dir?
        if self =~ /;|'|"|&|{|}|\^|\||\$|`|IFS|\s|<|>|\\|\?|\*|=/im
            return false
        end
        if self.length < 4
            return false
        end
        return true
    rescue
        return false
    end
end

def parse(html)
    html.xpath("//img").each do |i|
        if block_given?
            yield(i['src'])
        end
    end
end                                                       

begin
    path = Pathname.new(File.dirname(__FILE__)).realpath
    # hint = "flag is in /flag.txt"

    p "welcome to png images converter, please input a url:"
    url = gets.chomp

    p "I will create a special work directory for you, please input the dir name:"
    user_dir = gets.chomp

    if !url.is_valid_url? or !user_dir.is_valid_dir?
        p "?"
        exit(-1)
    end

    FileUtils.mkdir_p("#{path}/#{user_dir}", :mode => 0777)

rescue => ex
    p ex.message
    exit(-1)
end

begin
    File.open("#{path}/#{user_dir}/result.html", "w") do |file|
        html = Nokogiri::HTML(open(url, :read_timeout=>10 ))
        file.write("<html><body>")
        parse html do |img|
            if (URI(img).scheme != 'http' && URI(img).scheme != 'https') 
                img = "#{URI.parse(url).scheme}://#{URI.parse(url).host}:#{URI.parse(url).port}/#{img}"
            end

            begin
                file.write("<img src='data:image/png;base64,#{Base64.encode64(open(img, :read_timeout=>10).read).gsub(/\s/, "\n"=>'')}'>")
            rescue Net::ReadTimeout
                p "time out!"
            end
        end
        file.write("</body></html>")
    end

    p File.open("#{path}/#{user_dir}/result.html", "r").read
    
rescue => ex
    p ex.message
ensure
    exec "rm -rf #{path}/#{Shellwords.shellescape user_dir}/"
end